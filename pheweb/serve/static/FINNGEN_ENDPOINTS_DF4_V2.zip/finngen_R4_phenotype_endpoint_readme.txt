
# FINNGEN PHENOTYPE DATA RELEASE 4 NOTES
FinnGen phenotype data release 4 (August 2019).


## File structure 
### Data
#### Registry based endpoints
Path:
/finngen/library-red/finngen_R4/finngen_R4_phenotype_2.0/finngen_R4_phenotype_data/
|File|Description|
|---|---| 
finngen_R4_endpoint.gz| Registry based endpoints|


### Documentation
#### Case and control definitions
Path:
/finngen/library-red/finngen_R4/finngen_R4_phenotype_2.0/finngen_R4_phenotype_documentation/
|File|Description|
|---|---| 
finngen_R4_case_definitions.tsv|Case definitions by clinical team|
finngen_R4_control_definitions.tsv|Control definitions by clinical team|


## Misc
### Data description
Number of endpoint variables: 15306
Number of endpoints: 3822
Number of FinnGen IDs: 198328 

### Cohorts included
AURIA BIOBANK
BOREALIS BIOBANK
HELSINKI BIOBANK
BIOBANK OF CENTRAL FINLAND
BIOBANK OF EASTERN FINLAND
FINNISH CLINICAL BIOBANK TAMPERE
BLOOD SERVICE BIOBANK
TERVEYSTALO BB
THL BB
-BOTNIA
-COROGENE
-FINRISK 1992-2012
-FINHEALTH 2017
-FinIPF
-GENERISK
-HEALTH 2000/H2011
-KUUSAMO (=FR11)
-MIGRAINE
-SUPER
-T1D
-TWINS


### Data fields
|Field|Description|
|---|---| 	
FINNGENID|FINNGENID|	
BL_YEAR|Year of DNA sample collection|
BL_AGE|Age at DNA sample collection|	
FU_END_AGE|Age at the end of the follow up (31.12.2016)|
SEX|Gender (male/female/NA)|	
ENDPOINT_X|Endpoint name|
ENDPOINT_X_AGE|Age of onset|
ENDPOINT_X_YEAR|Year of onset|
ENDPOINT_NEVT|Number of events|
ENDPOINT_X_EXMORE|Endpoint_specific control definition, only for selected endpoints: More stringent control definition|
ENDPOINT_X_EXALLC|Endpoint specific control definition, only for selected endpoints: All cancer cases have been excluded from controls|


### Data notes
Endpoints with N cases <5 are not included in data
Endpoints with OMIT=2 in endpoint definition file are not included in data
String for missing values in the data is NA.
End of follow up: Registry data is available from beginning of registry until 31.12.2017

