

# FINNGEN PHENOTYPE DATA RELEASE 4 NOTES
FinnGen phenotype date release 4 (August 2019)



## File structure
### Data 

Path:
/finngen/library-red/finngen_R4/finngen_R4_phenotype_2.0/finngen_R4_phenotype_data/
|File|Description|
finngen_R4_minimum.gz|minimum phenotypes|


Number of FinnGen IDs: (196849) 
Number of minimum phenotypes variables: (15) 



### Includes 20 cohorts:

AURIA BIOBANK
BOREALIS BIOBANK
HELSINKI BIOBANK
BIOBANK OF CENTRAL FINLAND
BIOBANK OF EASTERN FINLAND
FINNISH CLINICAL BIOBANK TAMPERE
BLOOD SERVICE BIOBANK
TERVEYSTALO BB
THL BB
�	BOTNIA
�	COROGENE
�	FINRISK 1992-2012
�	FINHEALTH 2017
�	FinIPF
�	GENERISK
�	HEALTH 2000/H2011
�	KUUSAMO (=FR11)
�	MIGRAINE
�	SUPER
�	T1D
�	TWINS


### Data fields, includes 15 variables:

|Field|Description|
|-----|-----------|


FINNGENID|Study ID

BL_YEAR|Year of DNA sample collection

BL_AGE|Age at DNA sample collection (years)

SEX|Gender (male/female/NA)

HEIGHT|Height (cm)

HEIGHT_AGE|Age at height measurement (years)

WEIGHT|Weight (kg)

WEIGHT_AGE|Age at weight measurement (years)
				
SMOKE2|Smoking status 2-categories (yes/no)
			
SMOKE3|Smoking status 3-categories (current/former/never)         
			
SMOKE5|Smoking status 5-categories (current/occasional/quitter/former/never)
 			
SMOKE_AGE|Age at the moment of the smoking survey (years)

regionofbirth|Regional councils numbers for region of birth according to Finnish Minister of the Interior (21-categories)

regionofbirthname|Name of the region of birth (21-categories) (1-Uusima/2- Varsinais-Suomi/4-Satakunta/5-Kanta H�me/6-Pirkanmaa/7-P�ij�t  H�me/8-Kymenlaakso/9-South Karelia/10-Etel� Savo/11-Pohjois Savo/12-North Karelia/13-Central Finland/14-South Ostrobothnia/15-Ostrobothnia/16-Central Ostrobothnia/17-North Ostrobothnia/18-Kainuu/19-Lapland/20-�land/200-Abroad/9999-Region ceded to Soviet)|
			
moveabroad|If the person has moved abroad 3-categories (yes/no/NA)
			
              
### Data notes	

-If separate ages for height/weight were not available, then HEIGHT_AGE/WEIGHT_AGE were set to NA and the variable BL_AGE can be used instead.

-All minimum phenotypes were collected on the same date as sampling in the following cohorts: FINRISK, FINTERVEYS 2017, HEALTH 2000/2011 and SUPER.

-BOTNIA, GENERISK, T1D, BOREALIS BIOBANK and BLOOD SERVICE BIOBANK have some moderate divergence (a few months) between the sampling date and 
 the actual date when height/weight/smoking status data were collected although no separate dates for height/weight are available.

-T1D included some sampling dates with only month and year eg. "xx.mm.yyyy" and with only year eg. "yyyy".  
 In those cases dates were set to 15th of a given month eg. "15.mm.yyyy" and to 30.6. if both the date and month were missing eg. "30.6.yyyy".



